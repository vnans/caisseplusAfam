import { FlatpickrFn } from "./types/instance";
import "./utils/polyfills";
declare var flatpickr: FlatpickrFn;
export default flatpickr;
