<?php

namespace App\Entity;

use App\Repository\CoachRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=CoachRepository::class)
 */
class Coach
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\OneToMany(targetEntity=Abonnes::class, mappedBy="coach")
     */
    private $nomprenoms;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $nomcomplet;

    public function __construct()
    {
        $this->nomprenoms = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    /**
     * @return Collection|Abonnes[]
     */
    public function getNomprenoms(): Collection
    {
        return $this->nomprenoms;
    }

    public function addNomprenom(Abonnes $nomprenom): self
    {
        if (!$this->nomprenoms->contains($nomprenom)) {
            $this->nomprenoms[] = $nomprenom;
            $nomprenom->setCoach($this);
        }

        return $this;
    }

    public function removeNomprenom(Abonnes $nomprenom): self
    {
        if ($this->nomprenoms->removeElement($nomprenom)) {
            // set the owning side to null (unless already changed)
            if ($nomprenom->getCoach() === $this) {
                $nomprenom->setCoach(null);
            }
        }

        return $this;
    }

    public function getNomcomplet(): ?string
    {
        return $this->nomcomplet;
    }

    public function setNomcomplet(string $nomcomplet): self
    {
        $this->nomcomplet = $nomcomplet;

        return $this;
    }
}
