<?php

namespace App\Entity;

use App\Repository\EntraineurRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=EntraineurRepository::class)
 */
class Entraineur
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $coach;

    /**
     * @ORM\OneToMany(targetEntity=Abonnes::class, mappedBy="entraineur")
     */
    private $abonnes;

    public function __construct()
    {
        $this->abonnes = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCoach(): ?string
    {
        return $this->coach;
    }

    public function setCoach(string $coach): self
    {
        $this->coach = $coach;

        return $this;
    }

    /**
     * @return Collection|Abonnes[]
     */
    public function getAbonnes(): Collection
    {
        return $this->abonnes;
    }

    public function addAbonne(Abonnes $abonne): self
    {
        if (!$this->abonnes->contains($abonne)) {
            $this->abonnes[] = $abonne;
            $abonne->setEntraineur($this);
        }

        return $this;
    }

    public function removeAbonne(Abonnes $abonne): self
    {
        if ($this->abonnes->removeElement($abonne)) {
            // set the owning side to null (unless already changed)
            if ($abonne->getEntraineur() === $this) {
                $abonne->setEntraineur(null);
            }
        }

        return $this;
    }
}
