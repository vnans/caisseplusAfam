<?php

namespace App\Form;

use App\Entity\Abonnes;
use App\Entity\Entraineur;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\FileType;

class AbonnesType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('nomprenoms')
            ->add('tel')
            ->add('prix')

            ->add('DateDebut')
            ->add('DateFin')
            // ->add('entraineur', EntityType::class, array(
            //     'class' => Entraineur::class,
            //     'choice_label' => 'label'
            // ))
            ->add('photo', FileType::class, array('data_class' => NULL));
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Abonnes::class,
        ]);
    }
}
