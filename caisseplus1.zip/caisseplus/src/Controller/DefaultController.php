<?php

namespace App\Controller;

use DateTime;
use Dompdf\Dompdf;
use Dompdf\Options;
use App\Entity\User;
use App\Entity\Eleve;
use App\Entity\Caisse;
use App\Entity\Abonnes;
use App\Form\AbonnesType;
use App\Form\RegistrationFormType;
use App\Repository\AbonnesRepository;
use PhpOffice\PhpSpreadsheet\IOFactory;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class DefaultController extends AbstractController
{
    /**
     * @Route("/",name="acc")
     */
    public function acc()
    {
        return $this->render("default/acceuil.html.twig");
    }

    /**
     * @Route("/upload" , name="upload")
     */
    public function up(Request $request)
    {

        // dd($_FILES["import_excel"]["name"]);
        if ($request->isMethod('POST')) {
            // dd($_FILES["import_excel"]["name"]);
            $allowed_extension = array('xls', 'csv', 'xlsx');
            $file_array = explode(".", $_FILES["import_excel"]["name"]);
            $file_extension = end($file_array);

            if (in_array($file_extension, $allowed_extension)) {
                $file_name = time() . '.' . $file_extension;
                move_uploaded_file($_FILES['import_excel']['tmp_name'], $file_name);
                $file_type = \PhpOffice\PhpSpreadsheet\IOFactory::identify($file_name);
                $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($file_type);

                $spreadsheet = $reader->load($file_name);

                unlink($file_name);

                $data = $spreadsheet->getActiveSheet()->toArray();

                foreach ($data as $row) {
                    $insert_data = array(
                        ':first_name'  => $row[0],
                        ':last_name'  => $row[1],
                        ':created_at'  => $row[2],
                        ':updated_at'  => $row[3]
                    );

                    $eleve = new Eleve();
                    $eleve->setFirtname($row[0]);
                    $eleve->setLastname($row[1]);
                    $eleve->setCreatedAt(new \DateTime("now"));
                    $eleve->setUpdatedAt(new \datetime("now"));

                    $entityManager = $this->getDoctrine()->getManager();
                    $entityManager->persist($eleve);
                    $entityManager->flush();
                }
                $message = 1;
            } else {
                $message = 2;
            }
        } else {
            $message = 3;
        }



        return $this->render("default/upload.html.twig", [
            'message' =>  $message,
        ]);
    }

    /**
     * @Route("/uploadCaisse" , name="uploadCaisse")
     */
    public function uploadCaisse(Request $request)
    {

        // dd($_FILES["import_excel"]["name"]);
        if ($request->isMethod('POST')) {
            // dd($_FILES["import_excel"]["name"]);
            $allowed_extension = array('xls', 'csv', 'xlsx');
            $file_array = explode(".", $_FILES["import_excel"]["name"]);
            $file_extension = end($file_array);

            if (in_array($file_extension, $allowed_extension)) {
                $file_name = time() . '.' . $file_extension;
                move_uploaded_file($_FILES['import_excel']['tmp_name'], $file_name);
                $file_type = \PhpOffice\PhpSpreadsheet\IOFactory::identify($file_name);
                $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader($file_type);

                $spreadsheet = $reader->load($file_name);

                unlink($file_name);

                $data = $spreadsheet->getActiveSheet()->toArray();

                foreach ($data as $row) {
                    $insert_data = array(
                        ':Beneficiaire'  => $row[0],
                        ':Montant'  => $row[1],
                        ':Montant en lettre'  => $row[2],
                        ':Motif'  => $row[3]
                    );

                    $caisse = new Caisse();
                    $caisse->setBeneficiaire($row[0]);
                    $caisse->setMontant($row[1]);
                    $caisse->setMontantLettre($row[2]);
                    $caisse->setMotif($row[3]);
                    $caisse->setCreele(new \datetime("now"));

                    $entityManager = $this->getDoctrine()->getManager();
                    $entityManager->persist($caisse);
                    $entityManager->flush();
                }
                $message = 1;
            } else {
                $message = 2;
            }
        } else {
            $message = 3;
        }



        return $this->render("default/uploadCaisse.html.twig", [
            'message' =>  $message,
        ]);
    }
    /**
     * @Route("/stats",name="stats")
     */
    public function stats()
    {

        return $this->render("default/stats.html.twig");
    }

    /**
     * @Route("/default", name="default")
     */
    public function index(AbonnesRepository $abonnesRepository): Response
    {
        // les totaux  des abonnes et non abonnes
        $now = new \DateTime();

        $em = $this->getDoctrine()->getManager();
        $repoAbonnes = $em->getRepository(Abonnes::class);
        // 3. Query how many rows are there in the Articles table
        $totalAbonnes = $repoAbonnes->createQueryBuilder('a')
            // Filter by some parameter if you want
            // ->where('a.published = 1')
            ->select('count(a.id)')->getQuery()->getSingleScalarResult();

        // total des abonnes
        $lesabonnes = $repoAbonnes->createQueryBuilder('a')
            ->select('count(a.id)')
            ->where('a.prix >= 10000')
            ->getQuery()->getSingleScalarResult();

        // total Abonnes actif 
        $abact = $repoAbonnes->createQueryBuilder('a')
            // Filter by some parameter if you want
            // ->where('a.published = 1')
            ->select('count(a.id)')
            ->where('a.DateFin > \'' . $now->format('Y-m-d') . '\'')
            ->getQuery()->getSingleScalarResult();
        // dd($abact);

        // nombre Abonnes expiré 
        $abexp = $repoAbonnes->createQueryBuilder('a')
            // Filter by some parameter if you want
            // ->where('a.published = 1')
            ->where('a.DateFin < \'' . $now->format('Y-m-d') . '\'')
            ->select('count(a.id)')->getQuery()->getSingleScalarResult();


        return $this->render('default/index.html.twig', [
            'totalAbonnes' => $totalAbonnes,
            'abact' => $abact,
            'abexp' => $abexp,
            'lesabonnes' => $lesabonnes,
            'abonnes' => $abonnesRepository->findby(array(), array('creele' => 'DESC')),
        ]);
    }

    /**
     * @Route("/jour" , name="jour")
     */
    public function jour(Request $request): Response
    {


        if ($request->isMethod('POST')) {
            // si un calcul est demandé on envoi le resultat
            // je format ma date
            // dd();
            $date1 = new \DateTime($request->request->get('date1') . " 00:00:00");
            $date2 = new \DateTime($request->request->get('date1') . " 23:59:59");
            $em = $this->getDoctrine()->getManager();
            $results = $em->getRepository(Caisse::class)->createQueryBuilder('o')
                ->where('o.creele BETWEEN :date1 AND :date2')
                ->setParameter('date1', $date1)
                ->setParameter('date2', $date2)
                ->getQuery()
                ->getResult();

            // la somme totale
            $sommes = $em->getRepository(Caisse::class)->createQueryBuilder('o')
                ->select('SUM(o.montant) AS total')
                ->where('o.creele BETWEEN :date1 AND :date2')
                ->setParameter('date1', $date1)
                ->setParameter('date2', $date2)

                ->getQuery()
                ->getResult();
            // dd( $result);

            return $this->render('default/jour.html.twig', [

                'results' => $results,
                'sommes' => $sommes,
                'date1' => $date1,
            ]);
        } // sinon on affichge par defaut

        $now = new \DateTime();
        $em = $this->getDoctrine()->getManager();
        $results = $em->getRepository(Caisse::class)->createQueryBuilder('o')
            ->where('o.creele BETWEEN :date1 AND :date2')
            ->setParameter('date1', $now->format('Y-m-d 00:00:00'))
            ->setParameter('date2', $now->format('Y-m-d 23:59:59'))
            ->getQuery()
            ->getResult();
        // dd( $result);

        // la somme totale
        // dd($now->format('Y-m-d 23:59:59'));
        $sommes = $em->getRepository(Caisse::class)->createQueryBuilder('o')
            ->select('SUM(o.montant) AS total')
            ->where('o.creele BETWEEN :date1 AND :date2')
            ->setParameter('date1', $now->format('Y-m-d 00:00:00'))
            ->setParameter('date2', $now->format('Y-m-d 23:59:59'))
            // ->groupBy('o.creele')
            ->getQuery()
            ->getResult();
        // dd($somme);
        return $this->render('default/jour.html.twig', [
            'results' => $results,
            'sommes' => $sommes,
            'date1' => $now,

        ]);
    }


    /**
     * @Route("/periode" , name="periode")
     */
    public function periode(Request $request): Response
    {

        // lancer le traitement periodique si le formulaire est lancé
        if ($request->isMethod('POST')) {
            // je recurepere mes dates 
            $date1 = new \DateTime($request->request->get('date1') . " 00:00:00");
            $date2 = new \DateTime($request->request->get('date2') . " 23:59:59");
            $em = $this->getDoctrine()->getManager();
            $results = $em->getRepository(Caisse::class)->createQueryBuilder('o')
                ->where('o.creele BETWEEN :date1 AND :date2')
                ->setParameter('date1', $date1)
                ->setParameter('date2', $date2)
                ->getQuery()
                ->getResult();
            // dd( $result);

            // calcul de la somme total 
            // la somme totale
            // dd($now->format('Y-m-d 23:59:59'));
            $sommes = $em->getRepository(Caisse::class)->createQueryBuilder('o')
                ->select('SUM(o.montant) AS total')
                ->where('o.creele BETWEEN :date1 AND :date2')
                ->setParameter('date1', $date1)
                ->setParameter('date2', $date2)
                // ->groupBy('o.creele')
                ->getQuery()
                ->getResult();

            return $this->render('default/periode.html.twig', [

                'results' => $results,
                'sommes' => $sommes,
                'date1' => $date1,
                'date2' => $date2
            ]);
        }
        // je recurepere mes dates 
        $date1 = new \DateTime("now");
        $date2 = new \DateTime("now");
        $em = $this->getDoctrine()->getManager();
        $results = $em->getRepository(Caisse::class)->createQueryBuilder('o')
            ->where('o.creele BETWEEN :date1 AND :date2')
            ->setParameter('date1', $date1)
            ->setParameter('date2', $date2)
            ->getQuery()
            ->getResult();
        // dd( $result);
        // calcul de la somme total 
        // la somme totale
        // dd($now->format('Y-m-d 23:59:59'));
        $sommes = $em->getRepository(Caisse::class)->createQueryBuilder('o')
            ->select('SUM(o.montant) AS total')
            ->where('o.creele BETWEEN :date1 AND :date2')
            ->setParameter('date1', $date1)
            ->setParameter('date2', $date2)
            // ->groupBy('o.creele')
            ->getQuery()
            ->getResult();

        return $this->render('default/periode.html.twig', [
            'results' => $results,
            'sommes' => $sommes,
            'date1' => $date1,
            'date2' => $date2
        ]);
    }


    /**
     * @Route("/abonnement",name="abonnement")
     */
    public function abonnement(Request $request)
    {
        // liste de tous les abonnes
        $abonne = new Abonnes();
        $form = $this->createForm(AbonnesType::class, $abonne);
        $form->handleRequest($request);

        $em = $this->getDoctrine()->getManager();
        $abonnment = $em->getRepository(Abonnes::class);
        $totalAbonnes = $abonnment->createQueryBuilder('a')
            // Filter by some parameter if you want
            ->where('a.prix >= 10000')
            // ->select('count(a.id)')
            ->getQuery()->getResult();
        // ->getSingleScalarResult();
        return $this->render('abonnes/index.html.twig', [
            'abonnes' => $totalAbonnes,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/jourAbonne" , name="jourAbonne")
     */
    public function jourAbonne(Request $request): Response
    {


        if ($request->isMethod('POST')) {
            // si un calcul est demandé on envoi le resultat
            // je format ma date
            // dd();
            $date1 = new \DateTime($request->request->get('date1') . " 00:00:00");
            $date2 = new \DateTime($request->request->get('date1') . " 23:59:59");
            $em = $this->getDoctrine()->getManager();
            $results = $em->getRepository(Abonnes::class)->createQueryBuilder('o')
                ->where('o.creele BETWEEN :date1 AND :date2')
                ->setParameter('date1', $date1)
                ->setParameter('date2', $date2)
                ->getQuery()
                ->getResult();

            // la somme totale
            $sommes = $em->getRepository(Abonnes::class)->createQueryBuilder('o')
                ->select('SUM(o.prix) AS total')
                ->where('o.creele BETWEEN :date1 AND :date2')
                ->setParameter('date1', $date1)
                ->setParameter('date2', $date2)

                ->getQuery()
                ->getResult();
            // dd( $result);

            return $this->render('default/jourAbonne.html.twig', [

                'results' => $results,
                'sommes' => $sommes,
                'date1' => $date1,
            ]);
        } // sinon on affichge par defaut

        $now = new \DateTime();
        $em = $this->getDoctrine()->getManager();
        $results = $em->getRepository(Abonnes::class)->createQueryBuilder('o')
            ->where('o.creele BETWEEN :date1 AND :date2')
            ->setParameter('date1', $now->format('Y-m-d 00:00:00'))
            ->setParameter('date2', $now->format('Y-m-d 23:59:59'))
            ->getQuery()
            ->getResult();
        // dd( $result);

        // la somme totale
        // dd($now->format('Y-m-d 23:59:59'));
        $sommes = $em->getRepository(Abonnes::class)->createQueryBuilder('o')
            ->select('SUM(o.prix) AS total')
            ->where('o.creele BETWEEN :date1 AND :date2')
            ->setParameter('date1', $now->format('Y-m-d 00:00:00'))
            ->setParameter('date2', $now->format('Y-m-d 23:59:59'))
            // ->groupBy('o.creele')
            ->getQuery()
            ->getResult();
        // dd($somme);
        return $this->render('default/jourAbonne.html.twig', [
            'results' => $results,
            'sommes' => $sommes,
            'date1' => $now,

        ]);
    }


    /**
     * @Route("/periodeAbonne" , name="periodeAbonne")
     */
    public function periodeAbonne(Request $request): Response
    {

        // lancer le traitement periodique si le formulaire est lancé
        if ($request->isMethod('POST')) {
            // je recurepere mes dates 
            $date1 = new \DateTime($request->request->get('date1') . " 00:00:00");
            $date2 = new \DateTime($request->request->get('date2') . " 23:59:59");
            $em = $this->getDoctrine()->getManager();
            $results = $em->getRepository(Abonnes::class)->createQueryBuilder('o')
                ->where('o.creele BETWEEN :date1 AND :date2')
                ->setParameter('date1', $date1)
                ->setParameter('date2', $date2)
                ->getQuery()
                ->getResult();
            // dd( $result);

            // calcul de la somme total 
            // la somme totale
            // dd($now->format('Y-m-d 23:59:59'));
            $sommes = $em->getRepository(Abonnes::class)->createQueryBuilder('o')
                ->select('SUM(o.prix) AS total')
                ->where('o.creele BETWEEN :date1 AND :date2')
                ->setParameter('date1', $date1)
                ->setParameter('date2', $date2)
                // ->groupBy('o.creele')
                ->getQuery()
                ->getResult();

            return $this->render('default/periodeAbonne.html.twig', [

                'results' => $results,
                'sommes' => $sommes,
                'date1' => $date1,
                'date2' => $date2
            ]);
        }
        // je recurepere mes dates 
        $date1 = new \DateTime("now");
        $date2 = new \DateTime("now");
        $em = $this->getDoctrine()->getManager();
        $results = $em->getRepository(Caisse::class)->createQueryBuilder('o')
            ->where('o.creele BETWEEN :date1 AND :date2')
            ->setParameter('date1', $date1)
            ->setParameter('date2', $date2)
            ->getQuery()
            ->getResult();
        // dd( $result);
        // calcul de la somme total 
        // la somme totale
        // dd($now->format('Y-m-d 23:59:59'));
        $sommes = $em->getRepository(Caisse::class)->createQueryBuilder('o')
            ->select('SUM(o.montant) AS total')
            ->where('o.creele BETWEEN :date1 AND :date2')
            ->setParameter('date1', $date1)
            ->setParameter('date2', $date2)
            // ->groupBy('o.creele')
            ->getQuery()
            ->getResult();

        return $this->render('default/periodeAbonne.html.twig', [
            'results' => $results,
            'sommes' => $sommes,
            'date1' => $date1,
            'date2' => $date2
        ]);
    }






    /**
     * @Route("/abonnementAct",name="abonnementAct")
     */
    public function abonnementAct(Request $request)
    {
        // le formulaire 
        $abonne = new Abonnes();
        $form = $this->createForm(AbonnesType::class, $abonne);
        $form->handleRequest($request);

        $now = new \DateTime();
        $em = $this->getDoctrine()->getManager();
        $abonnment = $em->getRepository(Abonnes::class);
        $totalAbonnes = $abonnment->createQueryBuilder('a')
            // Filter by some parameter if you want
            ->where('a.DateFin > \'' . $now->format('Y-m-d') . '\'')
            ->getQuery()
            ->getResult();
        // dd($totalAbonnes);

        return $this->render('abonnes/index.html.twig', [
            'abonnes' => $totalAbonnes,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/abonnementExp",name="abonnementExp")
     */
    public function abonnementExp(Request $request)
    {
        // le formulaire 
        $abonne = new Abonnes();
        $form = $this->createForm(AbonnesType::class, $abonne);
        $form->handleRequest($request);
        $now = new \DateTime();
        $em = $this->getDoctrine()->getManager();
        $abonnment = $em->getRepository(Abonnes::class);
        $totalAbonnes = $abonnment->createQueryBuilder('a')
            // Filter by some parameter if you want
            ->where('a.DateFin < \'' . $now->format('Y-m-d') . '\'')
            // ->select('count(a.id)')->getQuery()->getSingleScalarResult();
            ->getQuery()->getResult();
        // dd($now->format('Y-m-d'));
        return $this->render('abonnes/index.html.twig', [
            'abonnes' => $totalAbonnes,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/imprim",name="imprim")
     */
    public function imprim()
    {
        // Configure Dompdf according to your needs
        $pdfOptions = new Options();
        $pdfOptions->set('defaultFont', 'Arial');

        // Instantiate Dompdf with our options
        $dompdf = new Dompdf($pdfOptions);

        // Retrieve the HTML generated in our twig file
        $html = $this->renderView('default/acceuil.html.twig', []);

        // Load HTML to Dompdf
        $dompdf->loadHtml($html);

        // (Optional) Setup the paper size and orientation 'portrait' or 'portrait'
        $dompdf->setPaper('A4', 'portrait');

        // Render the HTML as PDF
        $dompdf->render();

        // Output the generated PDF to Browser (inline view)
        $dompdf->stream("monrapport.pdf", [
            "Attachment" => false
        ]);
    }


    /**
     * @Route("/rapportdujour",name="rapportdujour")
     */
    public function rapportdujour(Request $request)
    {
        // Configure Dompdf according to your needs
        $pdfOptions = new Options();
        $pdfOptions->set('defaultFont', 'Arial');

        // Instantiate Dompdf with our options
        $dompdf = new Dompdf($pdfOptions);


        // if ($request->isMethod('POST')) {
        // si une recherche est faites on envoi le resultat
        // je format ma date
        // dd();
        $now = new \DateTime();
        $em = $this->getDoctrine()->getManager();
        $results = $em->getRepository(Caisse::class)->createQueryBuilder('o')
            ->where('o.creele BETWEEN :date1 AND :date2')
            ->setParameter('date1', '\'' . $now->format('Y-m-d 00:00:00') . '\'')
            ->setParameter('date2', $now->format('Y-m-d 23:59:59'))
            ->getQuery()
            ->getResult();
        // dd( $result);

        // la somme totale
        // dd($now->format('Y-m-d 23:59:59'));
        $sommes = $em->getRepository(Abonnes::class)->createQueryBuilder('o')
            ->select('SUM(o.montant) AS total')
            ->where('o.creele BETWEEN :date1 AND :date2')
            ->setParameter('date1', $now->format('Y-m-d 00:00:00'))
            ->setParameter('date2', $now->format('Y-m-d 23:59:59'))
            // ->groupBy('o.creele')
            ->getQuery()
            ->getResult();
        // dd( $result);
        // }
        // Retrieve the HTML generated in our twig file
        $html = $this->renderView('default/rapportdujour.html.twig', [
            'results' => $results,
            'sommes' => $sommes,
        ]);

        // Load HTML to Dompdf
        $dompdf->loadHtml($html);

        // (Optional) Setup the paper size and orientation 'portrait' or 'portrait'
        $dompdf->setPaper('A4', 'portrait');

        // Render the HTML as PDF
        $dompdf->render();

        // Output the generated PDF to Browser (inline view)
        $dompdf->stream("monrapport.pdf", [
            "Attachment" => false
        ]);
    }



    /**
     * @Route("/{id}/edit", name="config", methods={"GET","POST"})
     */
    public function config(Request $request, User $user): Response
    {
        $form = $this->createForm(RegistrationFormType::class, $user);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('default');
        }

        return $this->render('default/config.html.twig', [
            'user' => $user,
            'registrationForm' => $form->createView(),
        ]);
    }
}
