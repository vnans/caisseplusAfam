<?php

namespace App\Controller;

use App\Entity\Caisse;
use App\Form\CaisseType;
use js\tools\numbers2words\Speller;
use App\Repository\CaisseRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Intl\NumberFormatter\NumberFormatter;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

/**
 * @Route("/caisse")
 */
class CaisseController extends AbstractController
{
    /**
     * @Route("/", name="caisse_index", methods={"GET","POST"})
     */
    public function index(CaisseRepository $caisseRepository, Request $request): Response
    {
        // le formulaire 
        $caisse = new Caisse();
        $form = $this->createForm(CaisseType::class, $caisse);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            // dd($form->get('beneficiaire')->getData());
            // ajouter d'image
            // $file = $abonne->getPhoto();
            // $fileName = $this->generateUniqueFileName() . '.' . $file->guessExtension();
            // // moves the file to the directory where brochures are stored
            // $file->move($this->getParameter('images_directory'), $fileName); // stock image dans /public/img
            // $abonne->setPhoto($fileName);
            // $abonne->setOp($user->getNomprenoms());


            $formatter = \NumberFormatter::create('fr_FR', \NumberFormatter::SPELLOUT);
            $formatter->setAttribute(\NumberFormatter::FRACTION_DIGITS, 0);
            $formatter->setAttribute(\NumberFormatter::ROUNDING_MODE, \NumberFormatter::ROUND_HALFUP);

            // echo $formatter->format($form->get('montant')->getdata());
            $caisse->setMontantLettre($formatter->format($form->get('montant')->getdata()));
            // $caisse->setMontantLettre(Speller::spellNumber($form->get('montant')->getdata(), Speller::LANGUAGE_ENGLISH));
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($caisse);
            $entityManager->flush();

            return $this->redirectToRoute('caisse_index');
        }
        return $this->render('caisse/index.html.twig', [
            'caisses' => $caisseRepository->findBy(array(), array('id' => 'DESC')),
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/new", name="caisse_new", methods={"GET","POST"})
     */
    public function new(Request $request): Response
    {
        $caisse = new Caisse();
        $form = $this->createForm(CaisseType::class, $caisse);
        $form->handleRequest($request);
        dd($form);

        if ($form->isSubmitted() && $form->isValid()) {
            // $caisse->setMontantLettre(Speller::spellNumber(123, Speller::LANGUAGE_RUSSIAN));
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($caisse);
            $entityManager->flush();

            return $this->redirectToRoute('caisse_index');
        }

        return $this->render('caisse/new.html.twig', [
            'caisse' => $caisse,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="caisse_show", methods={"GET"})
     */
    public function show(Caisse $caisse): Response
    {
        return $this->render('caisse/show.html.twig', [
            'caisse' => $caisse,
        ]);
    }

    /**
     * @Route("/{id}/edit", name="caisse_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Caisse $caisse): Response
    {
        $form = $this->createForm(CaisseType::class, $caisse);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('caisse_index');
        }

        return $this->render('caisse/edit.html.twig', [
            'caisse' => $caisse,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="caisse_delete", methods={"POST"})
     */
    public function delete(Request $request, Caisse $caisse): Response
    {
        if ($this->isCsrfTokenValid('delete' . $caisse->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($caisse);
            $entityManager->flush();
        }

        return $this->redirectToRoute('caisse_index');
    }
}
